
<?php $__env->startSection("page-title","Sliders"); ?>
<?php $__env->startSection("main-content"); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Sliders</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            
                            
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Sliders List</h3>
                                <?php if(!empty($aclList[1][2])): ?>
                                    <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-primary float-right text-white">
                                        <i class="fas fa-plus-circle"></i>
                                        Add New
                                    </a>
                                <?php endif; ?>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Black Title</th>
                                        <th>Color Title</th>
                                        <th>Description</th>
                                        <th>Button Label</th>
                                        <th>Button Link</th>
                                        <th>Serial No.</th>
                                        <th>Image</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($slider->title_black); ?></td>
                                            <td><?php echo e($slider->title_color); ?></td>
                                            <td><?php echo nl2br($slider->description); ?></td>
                                            <td><?php echo e($slider->button_label); ?></td>
                                            <td><?php echo e(substr($slider->link, 0, 20)); ?></td>
                                            <td><?php echo e($slider->order_serial); ?></td>
                                            <td>
                                                <?php if(!empty($slider->slider_name)): ?>
                                                <a href="<?php echo e(URL::to('slider_image_show/' . $slider->id )); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($slider->slider_name)); ?>" width="100">
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($slider->status == 1): ?>
                                                    <button class="btn btn-xs btn-success">Active</button>
                                                <?php else: ?>
                                                    <button class="btn btn-xs btn-danger">Inactive</button>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if(!empty($aclList[1][3]) || !empty($aclList[1][4])): ?>
                                                    <form method="post" action="<?php echo e(route('slider.destroy',$slider->id)); ?>">
                                                        <?php if(!empty($aclList[1][3])): ?>
                                                            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('slider.edit',$slider->id)); ?>" title="Edit">
                                                                <i class="fas fa-pencil-alt"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php if(!empty($aclList[1][4])): ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Delete">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="10" class="text-center">Nothing Found</td>
                                        </tr>
                                    <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.master.main-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/slider/index.blade.php ENDPATH**/ ?>