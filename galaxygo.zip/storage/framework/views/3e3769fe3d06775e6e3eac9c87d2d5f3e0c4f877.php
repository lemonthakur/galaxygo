
<?php $__env->startSection('title','Registration'); ?>

<?php $__env->startSection('content'); ?>

    <section class="ic-login-area">
        <div class="container">
            <div class="ic-login-warper">
                <div class="ic-login-card">
                    <div class="ic-login-bg">
                        <img src="<?php echo e(asset('frontend/images/login-bg.png')); ?>" class="img-fluid" alt="login-bg">
                    </div>
                    <div class="logo text-center">
                        <a href="index.php"><img src="<?php echo e(asset('frontend/images/logo/logo.png')); ?>" class="img-fluid"
                                                 alt="logo"></a>
                    </div>
                    <div class="ic-heading text-center">
                        <h2><span>Register</span> now</h2>
                    </div>
                    <form action="<?php echo e(route('register.submit')); ?>" method="post" class="ic-login-form-warper">
                        <?php echo csrf_field(); ?>

                        <div class="form-group input-form-group mb-0">
                            <div class="icon">
                                <i class="icofont-ui-user"></i>
                            </div>
                            <input type="text" class="form-control login-input" name="name"
                                   placeholder="Enter User Name" value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="mb-3">
                            <span class="text-danger"><?php echo e($errors->has("name") ? $errors->first("name") : ""); ?></span>
                        </div>

                        <div class="form-group input-form-group mb-0">
                            <div class="icon">
                                <i class="flaticon-at"></i>
                            </div>
                            <input type="email" class="form-control login-input" name="email"
                                   placeholder="Enter Email Address" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="mb-3">
                            <span class="text-danger"><?php echo e($errors->has("email") ? $errors->first("email") : ""); ?></span>
                        </div>

                        <div class="form-group input-form-group mb-0">
                            <div class="icon">
                                <i class="flaticon-key"></i>
                            </div>
                            <input type="password" class="form-control login-input" name="password"
                                   placeholder="Enter Password">
                        </div>
                        <div class="mb-3">
                            <span
                                class="text-danger"><?php echo e($errors->has("password") ? $errors->first("password") : ""); ?></span>
                        </div>

                        <div class="form-group input-form-group mb-0">
                            <div class="icon">
                                <i class="flaticon-key"></i>
                            </div>
                            <input type="password" class="form-control login-input" name="confirm_password"
                                   placeholder="Enter Confirmed Password">
                        </div>
                        <div class="mb-3">
                            <span
                                class="text-danger"><?php echo e($errors->has("confirm_password") ? $errors->first("confirm_password") : ""); ?></span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="login-btn">Register now</button>
                        </div>

                        <div class="ic-or-login">
                            <p>or</p>
                        </div>
                        <div class="ic-social-login">
                            <a href="#"><i class="flaticon-facebook"></i> <span>login with facebook</span> </a>
                            <a href="<?php echo e(route('login')); ?>"><i class="flaticon-message"></i> <span>Login with email</span>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/register.blade.php ENDPATH**/ ?>