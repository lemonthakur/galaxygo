<form method="post" action="<?php echo e(route('win-coin.destroy',$id)); ?>">
            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('win-coin.edit',$id)); ?>" title="Edit">
                <i class="fas fa-pencil-alt"></i>
            </a>
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Delete">
                <i class="fas fa-trash-alt"></i>
            </button>
    </form>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/win-coin/action.blade.php ENDPATH**/ ?>