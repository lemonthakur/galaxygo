<?php if(Session::has('success')): ?>
    <script>
        var msg ='<?php echo e(Session::get("success")); ?>';
        Swal.fire(msg, "", "success");
    </script>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <script>
        var msg ='<?php echo e(Session::get("error")); ?>';
        Swal.fire(msg, "", "error");
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/include/errormsg.blade.php ENDPATH**/ ?>