
<?php $__env->startSection("page-title","Win Coin Create"); ?>
<?php $__env->startSection("main-content"); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Win Coin</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            
                            
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 offset-md-3">
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title">Create Win Coin</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form method="post" action="<?php echo e(route("win-coin.store")); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="win">Number of win<span class="text-danger">*</span></label>
                                                <input type="number" min="0"
                                                       class="form-control <?php echo e($errors->has("win") ? "is-invalid":""); ?>"
                                                       id="win" name="win" placeholder="Enter Number Of Win"
                                                       value="<?php echo e(old("win")); ?>" required>
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("win") ? $errors->first("win") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="out_of">Out of<span class="text-danger">*</span></label>
                                                <input type="number" min="10"
                                                       class="form-control <?php echo e($errors->has("out_of") ? "is-invalid":""); ?>"
                                                       id="out_of" name="out_of" placeholder="Enter Out Of"
                                                       value="<?php echo e(old("out_of")); ?>" required>
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("out_of") ? $errors->first("out_of") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="coin">Win Coin<span class="text-danger">*</span></label>
                                                <input type="number" min="10"
                                                       class="form-control <?php echo e($errors->has("coin") ? "is-invalid":""); ?>"
                                                       id="coin" name="coin" placeholder="Enter Win Coin"
                                                       value="<?php echo e(old("coin")); ?>" required>
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("coin") ? $errors->first("coin") : ""); ?> </span>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-dark">Submit</button>
                                    <button type="button" class="btn btn-default cancel">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.master.main-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/win-coin/create.blade.php ENDPATH**/ ?>