<?php if(!empty($aclList[1][3]) || !empty($aclList[1][4])): ?>
    <form method="post" action="<?php echo e(route('category.destroy',$id)); ?>">
        <?php if(!empty($aclList[1][3])): ?>
            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('category.edit',$id)); ?>" title="Edit">
                <i class="fas fa-pencil-alt"></i>
            </a>
        <?php endif; ?>
        <?php if(!empty($aclList[1][4])): ?>
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>

            <?php if($status == 1): ?>
                <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Inactive">
                    <i class="fas fa-times"></i>
                </button>
            <?php else: ?>
                <button type="submit" class="btn btn-xs btn-success text-white delete" title="Active">
                    <i class="fas fa-check"></i>
                </button>
            <?php endif; ?>
        <?php endif; ?>
    </form>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/category/action.blade.php ENDPATH**/ ?>