<?php if(Session::has('success')): ?>
    <script>
        toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "toast-top-center",
            }
        toastr.success("<?php echo e(session('success')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
        toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "toast-top-center",
            }
        toastr.error("<?php echo e(session('error')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <script>
        toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "toast-top-center",
            }
        toastr.error("<?php echo e(session('info')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
    <script>
        toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true,
                "positionClass": "toast-top-center",
            }
        toastr.error("<?php echo e(session('warning')); ?>");
    </script>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/include/toastr.blade.php ENDPATH**/ ?>