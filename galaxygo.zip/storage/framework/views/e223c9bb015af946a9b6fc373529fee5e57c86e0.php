<?php if($product_lists): ?>

    <?php $__currentLoopData = $product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apk => $apv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6 ic-col-xs-6">
            <div class="ic-product-item">
                <div class="ic-thumbnil">
                    <a href="<?php echo e(route('product-details', $apv->slug)); ?>">
                    <img src="<?php echo e(asset('upload/product-thumbnail-255-200/'.$apv->feature_image)); ?>"
                    class="img-fluid" alt="product"></a>
                    <span class="ic-badge">over</span>
                </div>
                <div class="ic-content">
                    <div class="title-price">
                        <a href="<?php echo e(route('product-details', $apv->slug)); ?>">
                            <h5><?php echo e($apv->name); ?></h5>
                            <?php
                                $price = $apv->price;
                                if($apv->discount_amount)
                                    $price = $apv->price-$apv->discount_amount;
                            ?>
                            <p>$<?php echo e(number_format($price, 2)); ?></p>
                        </a>
                    </div>
                    <div class="ic-btn-group">
                        <?php if($apv->product_type=='General Product'): ?>
                            <a href="<?php echo e(route('shopping.cart')); ?>" class="buy-btn">buy now</a>
                        <?php else: ?>
                            <a href="javascript:void(0)" class="bid-btn">bid now</a>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#bidModal" class="icon-btn"><i class="flaticon-time-left"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-12">
        <div class="ic-pagination">
            <?php echo e($product_lists->links('vendor.pagination.frontend')); ?>

        </div>
    </div>

<?php else: ?>
    <div class="col-md-12 text-center"><span class="text-danger">Product not available.</span></div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/ajax_blade/ajax_shop.blade.php ENDPATH**/ ?>