<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('content'); ?>
    <section class="ic-about-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="ic-about-left">
                        <img src="<?php echo e(asset($about->image)); ?>" class="img-fluid" alt="about">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="ic-about-right">
                        <h2><?php echo e(ucwords($about->title)); ?></h2>
                        <div>
                            <?php echo $about->description; ?>

                        </div>
                        <a href="<?php echo e($about->button_url); ?>" class="ic-btn "><?php echo e(ucwords($about->button_text)); ?></a>
                    </div>
                </div>
                <?php if($about->video_url): ?>
                <div class="col-12">
                    <div class="ic-about-video">
                        <div class="video-banner">
                            <img src="<?php echo e(asset($about->video_banner)); ?>" class="img-fluid" alt="about video">
                            <a class="ic-about-video-popup" data-autoplay="true" data-vbtype="video" href="<?php echo e($about->video_url); ?>">
                                <img src="<?php echo e(asset('/frontend/images/play-icon.png')); ?>" class="img-fluid play-icon" alt="play"></a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/about-us.blade.php ENDPATH**/ ?>