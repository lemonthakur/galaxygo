<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

    <section class="ic-entries-area">
        <div class="container">

            <div class="row">
                <div class="col-lg-4 col-md-5">
                    <div class="ic-profile-left">
                        <div class="ic-user">
                            <div class="ic-cover-bg">
                                <?php if(Auth::check() && Auth::user()->role_id == 0 && !empty(auth()->user()->cover_photo)): ?>
                                    <img id="cover_photo" src="<?php echo e(asset(auth()->user()->cover_photo)); ?>" class="img-fluid" alt="cover">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('frontend/images/profile-cover.png')); ?>" class="img-fluid" alt="cover">
                                <?php endif; ?>
                            </div>
                            <div class="user-profile">
                                    <?php if(Auth::check() && Auth::user()->role_id == 0 && !empty(auth()->user()->photo)): ?>
                                        <img src="<?php echo e(auth()->user()->photo); ?>" alt="user">
                                    <?php else: ?>
                                    <img id="profile_pic" src="<?php echo e(asset('demo-pic/download.png')); ?>" alt="user">
                                    <?php endif; ?>
                            </div>
                        </div>
                        <?php
                            if(Auth::check() && Auth::user()->role_id == 0){
                               $total_coins = auth()->user()->total_coin ?? 00;
                               $current_coins = auth()->user()->current_coin ?? 00;
                                }else{
                                    $mac = strtok(exec('getmac'), ' ');
                                    $guestUser = \App\Models\GuestUser::where('mac','=',$mac)->first();
                                    $total_coins = $guestUser->total_coin ?? 00;
                                    $current_coins = $guestUser->current_coin ?? 00;
                                }
                        ?>
                        <div class="ic-win-btn">
                            <a href="#"><?php echo e($entryWon ?? 00); ?> <span>Entries Won</span></a>
                            <a href="#"><?php echo e($total_coins); ?> <span>Coins Won</span></a>
                        </div>
                        <div class="ic-total-balance">
                            <p>Total Coins Balance</p>
                            <h4><?php echo e($current_coins); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7">
                    <div class="ic-entries-right">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#openEntries">Open Entries</a>
                            </li>
                            <li class="nav-item second-nav-item">
                                <a class="nav-link" data-toggle="tab" href="#pendingEntries">Pending Entries</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#finalEntries">Final Entries</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            
                            <div class="tab-pane fade show active" id="openEntries">
                                <div class="ic-entries-tab-contents open-entries">
                                    <?php if(!empty($contest) && strtotime($contest->expaire_time) >= $now): ?>
                                        <form method="post" action="<?php echo e(route('entries.store')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="contest_id" value="<?php echo e(encrypt($contest->id)); ?>">
                                            <div class="ic-pending-entries-title">
                                                <h5><?php echo e($contest->name ? date('d M',strtotime($contest->name)) : ''); ?></h5>
                                                <div class="ic-timer">
                                                    <span class="d-none"
                                                          id="timer-time"><?php echo e(date('M d,Y H:i:s',strtotime($contest->expaire_time)) ?? date('Y-m-d 0:00')); ?></span>
                                                    
                                                    
                                                    
                                                    
                                                    <div class="hours">
                                                        <h4 id="hour">00</h4>
                                                        <p>hours</p>
                                                    </div>
                                                    <div class="minute mr-3">
                                                        <h4 id="minute">00</h4>
                                                        <p>Minutes</p>
                                                    </div>
                                                    <div class="seconds">
                                                        <h4 id="second">00</h4>
                                                        <p>seconds</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php $__empty_1 = true; $__currentLoopData = $contest->contestPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contestPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <!--Item-->
                                                <div
                                                    class="ic-item <?php echo e($loop->iteration % 2 == 0 ? 'item-bg-mobile' : 'item-bg'); ?>">
                                                    <div class="user">
                                                        <div class="image">
                                                            <img src="<?php echo e(asset($contestPlayer->player_image)); ?>"
                                                                 alt="user">
                                                        </div>
                                                        <div class="name-title">
                                                            <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                            <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                        </div>
                                                        <div class="mobile-name-title name-title">
                                                            <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                            <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                            <p class="m-date"><?php echo e(date('D, M y, h:i A',strtotime($contestPlayer->played_on))); ?></p>
                                                            <p class="m-vs">
                                                                VS <?php echo e(strtoupper($contestPlayer->versus)); ?></p>
                                                            <p>
                                                                <span>project fantasy score</span> <?php echo e($contestPlayer->score); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="date">
                                                        <span><?php echo e(date('D, M y, h:i A',strtotime($contestPlayer->played_on))); ?></span>
                                                        <p>VS <?php echo e(strtoupper($contestPlayer->versus)); ?></p>
                                                    </div>
                                                    <div class="score">
                                                        <p><?php echo e($contestPlayer->score); ?></p>
                                                        <span>projets score</span>
                                                    </div>
                                                    <div class="over-under-btn">
                                                        
                                                        <input class="d-none" type="radio"
                                                               id="over_<?php echo e($contestPlayer->id); ?>_2" value="2"
                                                               name="players[<?php echo e($contestPlayer->id); ?>]"
                                                        <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 2)
                                                            ? 'checked' : ''); ?>>
                                                        <label id="over_lavel_<?php echo e($contestPlayer->id); ?>"
                                                               pid="<?php echo e($contestPlayer->id); ?>" ltype="2"
                                                               for="over_<?php echo e($contestPlayer->id); ?>_2"
                                                               class="over-btn mb-1 rlabel  <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 2)
                                                            ? 'active' : ''); ?>">over</label>
                                                        

                                                        
                                                        <input class="d-none" type="radio"
                                                               id="under_<?php echo e($contestPlayer->id); ?>_1" value="1"
                                                               name="players[<?php echo e($contestPlayer->id); ?>]"
                                                            <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                           && $contestPlayer->participant->participant_answer == 1)
                                                               ? 'checked' : ''); ?>>
                                                        <label id="under_lavel_<?php echo e($contestPlayer->id); ?>"
                                                               pid="<?php echo e($contestPlayer->id); ?>" ltype="1"
                                                               for="under_<?php echo e($contestPlayer->id); ?>_1" class="under-btn rlabel
                                                        <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 1)
                                                            ? 'active' : ''); ?>">under</label>
                                                        
                                                    </div>
                                                </div>
                                                <!--Item-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <h3 class="text-center">No Players Found</h3>
                                        <?php endif; ?>

                                        <!--Item End-->
                                            <div class="ic-item-load-more">
                                                
                                                <button type="submit" class="btn-submit">Submit</button>
                                            </div>
                                        </form>
                                    <?php else: ?>
                                        <h3 class="text-center text-white">Today's contest end</h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                            
                            <div class="tab-pane fade" id="pendingEntries">
                                <div class="ic-entries-tab-contents pending-entries">
                                    <div class="ic-pending-entries-title">
                                        <h5>pending entries</h5>
                                    </div>
                                <?php if(!empty($contest) && strtotime($contest->expaire_time) <= $now && $contest->is_final_answer == 0): ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $contest->contestPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contestPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <!--Item-->
                                            <div
                                                class="ic-item <?php echo e($loop->iteration % 2 == 0 ? 'item-bg-mobile' : 'item-bg'); ?>">
                                                <div class="user">
                                                    <div class="image">
                                                        <img src="<?php echo e(asset($contestPlayer->player_image)); ?>"
                                                             alt="user">
                                                    </div>
                                                    <div class="name-title">
                                                        <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                        <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                    </div>
                                                    <div class="mobile-name-title name-title">
                                                        <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                        <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                        <p class="m-date"><?php echo e(date('D, M y, h:i A',strtotime($contestPlayer->played_on))); ?></p>
                                                        <p class="m-vs">
                                                            VS <?php echo e(strtoupper($contestPlayer->versus)); ?></p>
                                                        <p>
                                                            <span>project fantasy score</span> <?php echo e($contestPlayer->score); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="date">
                                                    <span><?php echo e(date('D, M y, h:i A',strtotime($contestPlayer->played_on))); ?></span>
                                                    <p>VS <?php echo e(strtoupper($contestPlayer->versus)); ?></p>
                                                </div>
                                                <div class="score">
                                                    <p><?php echo e($contestPlayer->score); ?></p>
                                                    <span>projets score</span>
                                                </div>
                                                <div class="over-under-btn">
                                                    
                                                    <input class="d-none" type="radio"
                                                           id="over_<?php echo e($contestPlayer->id); ?>_2" value="2"
                                                           name="players[<?php echo e($contestPlayer->id); ?>]"
                                                        <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 2)
                                                            ? 'checked' : ''); ?>>
                                                    <label id="over_lavel_<?php echo e($contestPlayer->id); ?>"
                                                           pid="<?php echo e($contestPlayer->id); ?>" ltype="2"
                                                           for="over_<?php echo e($contestPlayer->id); ?>_2"
                                                           class="over-btn mb-1 rlabel  <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 2)
                                                            ? 'active' : ''); ?>">over</label>
                                                    

                                                    
                                                    <input class="d-none" type="radio"
                                                           id="under_<?php echo e($contestPlayer->id); ?>_1" value="1"
                                                           name="players[<?php echo e($contestPlayer->id); ?>]"
                                                        <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                       && $contestPlayer->participant->participant_answer == 1)
                                                           ? 'checked' : ''); ?>>
                                                    <label id="under_lavel_<?php echo e($contestPlayer->id); ?>"
                                                           pid="<?php echo e($contestPlayer->id); ?>" ltype="1"
                                                           for="under_<?php echo e($contestPlayer->id); ?>_1" class="under-btn rlabel
                                                        <?php echo e((!empty($contestPlayer->participant->participant_answer)
                                                        && $contestPlayer->participant->participant_answer == 1)
                                                            ? 'active' : ''); ?>">under</label>
                                                    
                                                </div>
                                            </div>
                                            <!--Item-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <h3 class="text-center">No Players Found</h3>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <h3 class="text-center text-white">No Pending Contest</h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                            <div class="tab-pane fade" id="finalEntries">
                                <div class="ic-entries-tab-contents final-entries">
                                <?php if(!empty($contest) && strtotime($contest->expaire_time) <= $now && $contest->is_final_answer == 1): ?>
                                        <div class="ic-time">
                                            <h4>Today's final entries</h4>
                                        </div>
                                    <?php $__empty_1 = true; $__currentLoopData = $contest->contestPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contestPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <!--Item 1-->
                                    <div class="ic-item  <?php echo e($loop->iteration % 2 == 0 ? 'item-bg-mobile' : 'item-bg'); ?>">
                                        <div class="user">
                                            <div class="image">
                                                <img src="<?php echo e(asset($contestPlayer->player_image)); ?>" alt="user">
                                            </div>
                                            <div class="name-title">
                                                <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                            </div>
                                            <div class="mobile-name-title name-title">
                                                <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                <p class="final-our-score">fantasy score</p>
                                                <p class="final-score-point"><?php echo e($contestPlayer->score); ?></p>
                                            </div>
                                        </div>
                                        <div class="over-projection">
                                            <?php if(!empty($contestPlayer->participant->participant_answer)): ?>
                                                <?php if($contestPlayer->participant->participant_answer == 2): ?>
                                                    <div class="over-icon">
                                                        <a href="#">over</a>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="under-icon">
                                                        <a href="#">under</a>
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <div class="over-icon">
                                                    <a href="#">No Answer</a>
                                                </div>
                                            <?php endif; ?>
                                            <span>your projection</span>
                                        </div>

                                        <div class="over-projection mobile-over-projection">
                                            <?php if(!empty($contestPlayer->participant->participant_answer)): ?>
                                                <?php if($contestPlayer->participant->participant_answer == 2): ?>
                                                    <a href="#">over</a>
                                                <?php else: ?>
                                                    <a href="#">under</a>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <a href="#">under</a>
                                            <?php endif; ?>
                                            <p><?php echo e($contestPlayer->score); ?><span>fantasy score</span></p>
                                        </div>

                                        <div class="score">
                                            <p><?php echo e($contestPlayer->score); ?></p>
                                            <span>fantasy score</span>
                                        </div>
                                        <div class="final-fantacy-score">
                                            <?php if(!empty($contestPlayer->participant->participant_answer) &&
                                              $contestPlayer->answer == $contestPlayer->participant->participant_answer): ?>
                                            <a href="#" class="final-remove check">
                                                <i class="flaticon-tick-mark"></i>
                                                final
                                            </a>
                                            <?php else: ?>
                                            <a href="#" class="final-remove">
                                                <i class="flaticon-error"></i>
                                                final
                                            </a>
                                            <?php endif; ?>
                                            <p><?php echo e($contestPlayer->score); ?> <span>fantasy score</span></p>
                                        </div>
                                    </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <h3 class="text-center">No Players Found</h3>
                                        <?php endif; ?>

                                        <div class="ic-item-load-more">
                                                <?php if(!empty($contest->userPLay) && $contest->userPLay->get_coin == 0): ?>
                                                <form method="post" action="<?php echo e(route('entries.claim.coin')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e(encrypt($contest->id)); ?>">
                                                    <button type="submit" class="btn-submit">
                                                        <i class="icofont-coins mr-1"></i>
                                                        Claim Coin
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                        </div>

                                    <?php else: ?>
                                        <h3 class="text-center text-white">Today's answer not submitted yet.</h3>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if(!empty($latest7contests)): ?>
                                    <?php $__currentLoopData = $latest7contests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="ic-entries-tab-contents mt-3 final-entries">
                                            <div class="ic-time">
                                                <h4><?php echo e($contest->name ? date('d M',strtotime($contest->name)) : ''); ?></h4>
                                            </div>
                                            <?php if(!empty($contest) && strtotime($contest->expaire_time) <= $now && $contest->is_final_answer == 1): ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $contest->contestPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contestPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <!--Item 1-->
                                                    <div class="ic-item  <?php echo e($loop->iteration % 2 == 0 ? 'item-bg-mobile' : 'item-bg'); ?>">
                                                        <div class="user">
                                                            <div class="image">
                                                                <img src="<?php echo e(asset($contestPlayer->player_image)); ?>" alt="user">
                                                            </div>
                                                            <div class="name-title">
                                                                <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                                <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                            </div>
                                                            <div class="mobile-name-title name-title">
                                                                <p><?php echo e(ucwords($contestPlayer->player_name)); ?></p>
                                                                <span><?php echo e(strtoupper($contestPlayer->location)); ?></span>
                                                                <p class="final-our-score">fantasy score</p>
                                                                <p class="final-score-point"><?php echo e($contestPlayer->score); ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="over-projection">
                                                            <?php if(!empty($contestPlayer->participant->participant_answer)): ?>
                                                                <?php if($contestPlayer->participant->participant_answer == 2): ?>
                                                                    <div class="over-icon">
                                                                        <a href="#">over</a>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="under-icon">
                                                                        <a href="#">under</a>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="over-icon">
                                                                    <a href="#">No Answer</a>
                                                                </div>
                                                            <?php endif; ?>
                                                            <span>your projection</span>
                                                        </div>

                                                        <div class="over-projection mobile-over-projection">
                                                            <?php if(!empty($contestPlayer->participant->participant_answer)): ?>
                                                                <?php if($contestPlayer->participant->participant_answer == 2): ?>
                                                                    <a href="#">over</a>
                                                                <?php else: ?>
                                                                    <a href="#">under</a>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <a href="#">under</a>
                                                            <?php endif; ?>
                                                            <p><?php echo e($contestPlayer->score); ?><span>fantasy score</span></p>
                                                        </div>

                                                        <div class="score">
                                                            <p><?php echo e($contestPlayer->score); ?></p>
                                                            <span>fantasy score</span>
                                                        </div>
                                                        <div class="final-fantacy-score">
                                                            <?php if(!empty($contestPlayer->participant->participant_answer) &&
                                                              $contestPlayer->answer == $contestPlayer->participant->participant_answer): ?>
                                                                <a href="#" class="final-remove check">
                                                                    <i class="flaticon-tick-mark"></i>
                                                                    final
                                                                </a>
                                                            <?php else: ?>
                                                                <a href="#" class="final-remove">
                                                                    <i class="flaticon-error"></i>
                                                                    final
                                                                </a>
                                                            <?php endif; ?>
                                                            <p><?php echo e($contestPlayer->score); ?> <span>fantasy score</span></p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <h3 class="text-center">No Players Found</h3>
                                                <?php endif; ?>

                                                <div class="ic-item-load-more">
                                                    <?php if(!empty($contest->userPLay) && $contest->userPLay->get_coin == 0): ?>
                                                        <form method="post" action="<?php echo e(route('entries.claim.coin')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e(encrypt($contest->id)); ?>">
                                                            <button type="submit" class="btn-submit">
                                                                <i class="icofont-coins mr-1"></i>
                                                                Claim Coin
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>

                                            <?php else: ?>
                                                <h4 class="text-center text-white">Answer not submitted.</h4>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

                $(".rlabel").on('click',function (){
                    let pid = $(this).attr('pid');
                    let ltype = $(this).attr('ltype');
                    $(this).addClass('active');

                    if (ltype === "1"){
                        console.log(pid,ltype);
                        console.log('#over_lavel_'+pid)
                        $('#over_lavel_'+pid).removeClass('active');
                    }else{
                        console.log(pid,ltype);
                        console.log('#under_lavel_'+pid)
                        $('#under_lavel_'+pid).removeClass('active');
                    }
                });

            // Count down timer
            var getTime = $('#timer-time').text();

            function makeTimer() {
                if (Date.parse(getTime) < Date.parse(new Date())) {
                    getTime = new Date();
                    $('.open-entries').empty();
                    $('.open-entries').html('<h3 class="text-center text-white">Today\'s contest end</h3>');
                }

                var endTime = new Date(getTime);
                console.log(endTime);
                endTime = (Date.parse(endTime) / 1000);

                var now = new Date();
                now = (Date.parse(now) / 1000);

                var timeLeft = endTime - now;

                var days = Math.floor(timeLeft / 86400);
                var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
                var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
                var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

                if (hours < "10") {
                    hours = "0" + hours;
                }
                if (minutes < "10") {
                    minutes = "0" + minutes;
                }
                if (seconds < "10") {
                    seconds = "0" + seconds;
                }

                // $("#day").text(days);
                $("#hour").text(hours);
                $("#minute").text(minutes);
                $("#second").text(seconds);
            }

            setInterval(function () {
                makeTimer();
            }, 1000);
            // makeTimer();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/entries.blade.php ENDPATH**/ ?>