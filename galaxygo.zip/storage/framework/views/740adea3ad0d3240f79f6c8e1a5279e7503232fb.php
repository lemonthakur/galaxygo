
<?php $__env->startSection('title','Forgot Password'); ?>

<?php $__env->startSection('content'); ?>

    <section class="ic-login-area">
        <div class="container">
            <div class="ic-login-warper">
                <div class="ic-login-card">
                    <div class="ic-login-bg">
                        <img src="<?php echo e(asset('frontend/images/login-bg.png')); ?>" class="img-fluid" alt="login-bg">
                    </div>
                    <div class="logo text-center">
                        <a href="index.php"><img src="<?php echo e(asset('frontend/images/logo/logo.png')); ?>" class="img-fluid"
                                                 alt="logo"></a>
                    </div>
                    <div class="ic-heading text-center">
                        <h2><span>Reset</span> Password</h2>
                    </div>
                    <form method="post" action="<?php echo e(route('forget.password.post')); ?>" class="ic-login-form-warper">

                        <?php echo csrf_field(); ?>
                        <div class="form-group input-form-group mb-0">
                            <div class="icon">
                                <i class="flaticon-at"></i>
                            </div>
                            <input type="email" class="form-control login-input" placeholder="example@gmail.com"
                                   name="email" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="mb-3">
                            <span class="text-danger"><?php echo e($errors->has("email") ? $errors->first("email") : ""); ?></span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="login-btn"> Send Password Reset Link</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/auth/forgetPassword.blade.php ENDPATH**/ ?>