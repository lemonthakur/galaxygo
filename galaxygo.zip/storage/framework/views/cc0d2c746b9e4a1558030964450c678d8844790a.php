<!--===Header Area Start===-->

<header>
    <div class="container">
        <div class="ic-header-warper profile-header-warper">
            <div class="logo">
                <?php if(!empty($siteSetting->logo)): ?>
                    <a href="<?php echo e(route('home')); ?>" class="large-logo"><img src="<?php echo e(asset($siteSetting->logo)); ?>" class="img-fluid" alt="logo"></a>
                <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>" class="large-logo"><img src="<?php echo e(asset('frontend/images/logo/logo.png')); ?>" class="img-fluid" alt="logo"></a>
                <?php endif; ?>

                <?php if(!empty($siteSetting->icon)): ?>
                    <a href="<?php echo e(route('home')); ?>" class="mobile-logo"><img src="<?php echo e(asset($siteSetting->icon)); ?>" class="img-fluid" alt="logo"></a>
                <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>" class="mobile-logo"><img src="<?php echo e(asset('frontend/images/logo/mobile-logo.png')); ?>" class="img-fluid" alt="logo"></a>
                <?php endif; ?>






            </div>
            <div class="ic-header-right ic-profile-header">
                <div class="ic-menu-item">
                    <ul class="ic-navbar">
                        <li class="ic-nav-item"><a href="#" class="ic-nav-link">Board</a></li>
                        <li class="ic-nav-item"><a href="<?php echo e(route('entries')); ?>" class="ic-nav-link">Entries</a></li>
                        <li class="ic-nav-item"><a href="<?php echo e(route('my.orders')); ?>" class="ic-nav-link">orders</a></li>
                    </ul>
                </div>

                <div class="ic-profile-header-btn">



                    <div class="dropdown show">
                        <a class="ic-btn profile-dropdown-item dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="flaticon-login"></i>
                            <span><?php echo e(ucwords(auth()->user()->name)); ?></span>
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
                        </div>
                    </div>

                    <a href="#" class="ic-btn"><i class="flaticon-coins-1"></i> <span>Coins Balance: <span class="aft-bd-share"><?php echo e(auth()->user()->current_coin); ?></span></span></a>
                    

                    <?php if(auth()->guard()->guest()): ?>
                    <a href="#" class="mobile-profile-user"><img src="<?php echo e(asset('frontend/images/profile-user.png')); ?>"
                                                                 alt=""></a>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->photo): ?>
                    <a href="#" class="mobile-profile-user"><img src="<?php echo e(auth()->user()->photo); ?>"
                                                                 alt=""></a>
                        <?php else: ?>
                            <a href="#" class="mobile-profile-user"><img src="<?php echo e(asset('frontend/images/profile-user.png')); ?>"
                                                                         alt=""></a>
                            <?php endif; ?>
                    <?php endif; ?>
                    <a href="#" class="ic-mobile-menu-open">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- mobile-nav start -->
    <div class="ic-mobile-menu-overlay"></div>
    <div class="offcanvas_menu d-block d-lg-none ic_mobile_nav_head">
        <div class="container">
            <div class="ic-mobile-menu-wrapper">
                <div class="ic-menu-close">
                    <a href="javascript:void(0)"><i class="icofont-close-circled"></i></a>
                </div>
                <div id="menu" class="text-left ">
                    <ul class="ic-mobile-menu">

                        <li class="ic-menu-item-has-children">
                            <a href="#">Board</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="<?php echo e(route('entries')); ?>">Entries</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">orders</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">About us</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">Contact us</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">Rules</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">Privacy</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#">Terms & Condition</a>
                        </li>
                        <li class="ic-menu-item-has-children">
                                <span class="menu-expand">
                                    <i class="icofont-simple-down"></i>
                                </span>
                            <a href="#"><i class="flaticon-login menu-icon"></i> <?php echo e(ucwords(auth()->user()->name)); ?></a>
                        </li>
                        <li class="ic-menu-item-has-children">
                            <a href="#"><i class="flaticon-coins-1 menu-icon"></i> Coins Balance: <?php echo e(auth()->user()->current_coin); ?></a>
                        </li>
                    </ul>

                </div>

            </div>
        </div>
    </div>

    <!--Mobile Nav End-->
</header>

<!--===Header Area End===-->
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/include/profile-header.blade.php ENDPATH**/ ?>