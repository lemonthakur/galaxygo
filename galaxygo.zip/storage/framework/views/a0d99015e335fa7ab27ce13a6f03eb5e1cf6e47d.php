<div class="form-group select2-parent">
    <select name="order_status" class="form-control single-select2 order_status" data-id=<?php echo e($id); ?> style="width: 100%;">
        <option selected disabled>Select One</option>
        <option value="Pending" <?php if($status=='Pending'): ?> selected <?php endif; ?>>Pending</option>
        <option value="Fulfilment" <?php if($status=='Fulfilment'): ?> selected <?php endif; ?>>Fulfilment</option>
        <option value="Cancle" <?php if($status=='Cancle'): ?> selected <?php endif; ?>>Cancle</option>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/orders/dropdown.blade.php ENDPATH**/ ?>