
    <form method="post" action="<?php echo e(route('contest.destroy',$id)); ?>">
        <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('contest.edit',$id)); ?>" title="Edit">
            <i class="fas fa-pencil-alt"></i>
        </a>
        <a class="btn btn-xs btn-info text-white" href="<?php echo e(route('contest.answer',$id)); ?>" title="Answer Submit">
            <i class="fas fa-question"></i>
        </a>

            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Delete">
                <i class="fas fa-trash-alt"></i>
            </button>
    </form>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/contest/action.blade.php ENDPATH**/ ?>