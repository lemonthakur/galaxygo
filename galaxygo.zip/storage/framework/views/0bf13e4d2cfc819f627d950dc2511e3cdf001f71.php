
<?php $__env->startSection("page-title","Footer"); ?>
<?php $__env->startSection("main-content"); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Footer Circle Image</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Circle Image List</h3>
                                <?php if(!empty($aclList[1][2])): ?>
                                    <a href="<?php echo e(route('footer-circle-image.create')); ?>" class="btn btn-primary float-right text-white">
                                        <i class="fas fa-plus-circle"></i>
                                        Add New
                                    </a>
                                <?php endif; ?>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Link</th>
                                        <th>Serial No.</th>
                                        <th>Image</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $cir_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cir_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($cir_image->title); ?></td>
                                            <td><?php echo e(substr($cir_image->link, 0, 20)); ?></td>
                                            <td><?php echo e($cir_image->order_serial); ?></td>
                                            <td>
                                                <?php if(!empty($cir_image->image_name)): ?>
                                                <a href="<?php echo e(URL::to('circle_image_show/' . $cir_image->id )); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($cir_image->image_name)); ?>" width="100">
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($cir_image->status == 1): ?>
                                                    <button class="btn btn-xs btn-success">Active</button>
                                                <?php else: ?>
                                                    <button class="btn btn-xs btn-danger">Inactive</button>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if(!empty($aclList[1][3]) || !empty($aclList[1][4])): ?>
                                                    <form method="post" action="<?php echo e(route('footer-circle-image.destroy',$cir_image->id)); ?>">
                                                        <?php if(!empty($aclList[1][3])): ?>
                                                            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('footer-circle-image.edit',$cir_image->id)); ?>" title="Edit">
                                                                <i class="fas fa-pencil-alt"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php if(!empty($aclList[1][4])): ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Delete">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">Nothing Found</td>
                                        </tr>
                                    <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.master.main-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/footer-circle-image/index.blade.php ENDPATH**/ ?>