
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

<section class="ic-checkout-area">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="ic-checkout-payment-left">
                    <div class="title">
                        <h2>checkout</h2>
                    </div>
                    <form action="<?php echo e(route("checkout.register")); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="ic-checkout-paymnet-card">
                            <div class="ic-express-checkout">
                                <p>Express Checkout</p>
                                <label class="mb-3 <?php echo e((old("payment_method")==1 || old("payment_method")==null || old("payment_method") == '')? 'active':''); ?>" id="paypalLabel" for="paypal"><i class="flaticon-paypal mr-1"></i> buy with paypal</label>
                                <input class="d-none" id="paypal" type="radio" value="1" name="payment_method"
                                        <?php echo e((old("payment_method")==1 || old("payment_method")==null || old("payment_method") == '')? 'checked':''); ?>>

                                <label id="coinLabel" class="<?php echo e((old("payment_method")==2) ? 'active':''); ?>" for="coin"><i class="icofont-coins mr-1"></i> buy with coin</label>
                                <input class="d-none" id="coin" type="radio" value="2" name="payment_method" <?php echo e((old("payment_method")==2) ? 'checked':''); ?>>
                                <span class="text-danger"> <?php echo e($errors->has("payment_method") ? $errors->first("payment_method") : ""); ?> </span>
                            </div>
                            <div class="or-pay">
                                <p><span>OR</span> To pay by credit card, purchase order or check, start by entering your shipping address bellow</p>
                            </div>

                            <div class="ic-payment-checkout-form">
                                <?php if(!\Auth::check()): ?>
                                    <p>Already have an account? <a href="<?php echo e(route('login').'?checkoutpg=pg'); ?>">Log in</a> </p>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="email" name="email" class="form-control" value="<?php echo e(old("email", \Auth::check() ? Auth::user()->shipping_email : '')); ?>" placeholder="Email address" >
                                            <span class="text-danger"> <?php echo e($errors->has("email") ? $errors->first("email") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control" value="<?php echo e(old("name", \Auth::check() ? Auth::user()->name : '')); ?>" placeholder="First Name" >
                                            <span class="text-danger"> <?php echo e($errors->has("name") ? $errors->first("name") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="last_name" class="form-control" value="<?php echo e(old("last_name", \Auth::check() ? Auth::user()->last_name : '')); ?>" placeholder="last Name" >
                                            <span class="text-danger"> <?php echo e($errors->has("last_name") ? $errors->first("last_name") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" name="shipping_company_name" class="form-control" value="<?php echo e(old("shipping_company_name", \Auth::check() ? Auth::user()->shipping_company_name : '')); ?>" placeholder="company Name (optional)">
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_company_name") ? $errors->first("shipping_company_name") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" name="shipping_adrress_line_1" value="<?php echo e(old("shipping_adrress_line_1", \Auth::check() ? Auth::user()->shipping_adrress_line_1 : '')); ?>" class="form-control" placeholder="Adrress line 1" >
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_adrress_line_1") ? $errors->first("shipping_adrress_line_1") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" name="shipping_adrress_line_2" class="form-control" value="<?php echo e(old("shipping_adrress_line_2", \Auth::check() ? Auth::user()->shipping_adrress_line_2 : '')); ?>" placeholder="Adrress line 2 (optional)">
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_adrress_line_2") ? $errors->first("shipping_adrress_line_2") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" name="shipping_city" value="<?php echo e(old("shipping_city", \Auth::check() ? Auth::user()->shipping_city : '')); ?>" class="form-control" placeholder="city" >
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_city") ? $errors->first("shipping_city") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <select name="shipping_country" id="" >
                                                <option value="">country</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($c->id); ?>" <?php if($c->id == old("shipping_country", \Auth::check() ? Auth::user()->shipping_country : '')): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($c->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_country") ? $errors->first("shipping_country") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="shipping_post_code" value="<?php echo e(old("shipping_post_code", \Auth::check() ? Auth::user()->shipping_post_code : '')); ?>" class="form-control" placeholder="Post Code" >
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_post_code") ? $errors->first("shipping_post_code") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <?php if(!\Auth::check()): ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="password" name="password" value="" class="form-control" placeholder="Password" >
                                            <span class="text-danger"> <?php echo e($errors->has("password") ? $errors->first("password") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="password" name="confirm_password" value="" class="form-control" placeholder="Confirm Password" >
                                            <span class="text-danger"> <?php echo e($errors->has("confirm_password") ? $errors->first("confirm_password") : ""); ?> </span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" name="shipping_phone" value="<?php echo e(old("shipping_phone", \Auth::check() ? Auth::user()->shipping_phone : '')); ?>" class="form-control" placeholder="Phone number" >
                                            <span class="text-danger"> <?php echo e($errors->has("shipping_phone") ? $errors->first("shipping_phone") : ""); ?> </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="continue-payment-shipping-btn">
                            <?php if(Cart::subtotal()>0 && Cart::count() > 0): ?>
                                <button type="submit" class="ic-btn payment-btn"> <span>Continue Payment</span></button>
                            <?php endif; ?>
                            <!-- <a href="<?php echo e(route('payment')); ?>" class="ic-btn shopping-btn" style="background-color: #D6BA4F"> <span>Continue Payment</span></a> -->
                            <a href="<?php echo e(route('shop')); ?>" class="ic-btn shopping-btn">Continue Shopping</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="ic-total-cart">
                    <h2>Total cart</h2>
                    <?php $shipping_cost = 0; ?>
                    <?php if(Cart::count() > 0): ?>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="total-cart-item">
                                <div class="image-title">
                                    <div class="image">
                                        <img src="<?php echo e(asset('upload/product-thumbnail-82-82/'.$row->options->image_name)); ?>" alt="">
                                    </div>
                                    <div class="title">
                                        <h4><?php echo e($row->name); ?></h4>
                                        <p>#<?php echo e($row->options->slug); ?></p>
                                        <p class="mobile-price">Price: <?php echo e($row->qty); ?> X $<?php echo e($row->price); ?></p>
                                    </div>
                                </div>
                                <div class="price">
                                    <p>Price</p>
                                    <span><?php echo e($row->qty); ?> X $<?php echo e($row->price); ?></span>
                                </div>
                            </div>
                            <?php $shipping_cost += $row->options->delivery_charge*$row->qty; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div class="ic-coupon-input">
                        <input type="text" class="form-control" placeholder="Coupon Or Discount Code">
                        <a href="#" class="ic-btn">apply</a>
                    </div>
                    <div class="ic-total-amount-calculate">
                        <div class="ic-subtotal">
                            <h5>subtotal</h5>
                            <h4>$<?php echo e(Cart::subtotal()); ?></h4>
                        </div>
                        <div class="ic-shipping-charge-amount">
                            <div class="shipping-charge">
                                <h5>Shipping Charge</h5>
                                <p>Calculate Shipping Charge</p>
                            </div>
                            <h4>$<?php echo e($shipping_cost); ?></h4>
                        </div>
                        <div class="ic-total-amount">
                            <h5>TOTAL</h5>
                            <h4>$<?php echo e(number_format(Cart::subtotal(2, '.', '')+$shipping_cost, 2, '.', ',')); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function (){
            $('#paypalLabel').on('click',function (){
               $(this).addClass('active');
               $('#coinLabel').removeClass('active');
            });

            $('#coinLabel').on('click',function (){
                $(this).addClass('active');
                $('#paypalLabel').removeClass('active');
            });

            var order_error_cancel = '<?php echo e(Session::has('order_error')); ?>';
            if(order_error_cancel){
                toastr.options =
                    {
                        "closeButton" : true,
                        "progressBar" : true
                    }
                toastr.error("Your payment has been cancelled.");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>