<?php if(!empty($aclList[6][3]) || !empty($aclList[6][4])): ?>
    <form method="post" action="<?php echo e(route('user.destroy',$id)); ?>">
        <?php if(!empty($aclList[6][3])): ?>
            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('user.edit',$id)); ?>" title="Edit">
                <i class="fas fa-pencil-alt"></i>
            </a>
        <?php endif; ?>
        <?php if(!empty($aclList[6][4])): ?>
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-xs btn-danger text-white delete" title="Delete">
                <i class="fas fa-trash-alt"></i>
            </button>
        <?php endif; ?>
    </form>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/user/action.blade.php ENDPATH**/ ?>