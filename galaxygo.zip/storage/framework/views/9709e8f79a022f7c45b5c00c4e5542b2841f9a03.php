
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

<section class="ic-cart-area">
    <div class="container">
        <form action="" method="post" id="update-cart-form">
            <?php echo csrf_field(); ?>
            <div class="ic-cart-card">
                <div class="title">
                    <h2>Shopping Cart</h2>
                </div>
                <?php if(Cart::count() > 0): ?>
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $product = \App\Models\Product::find($row->id);
                        ?>
                        <div class="ic-cart-item <?php if($loop->iteration % 2 != 0): ?><?php echo e('item-bg'); ?><?php else: ?><?php echo e('mobile-item-bg'); ?><?php endif; ?>">
                            <div class="image">
                                <img src="<?php echo e(asset('upload/product-thumbnail-82-82/'.$row->options->image_name)); ?>" alt="">
                            </div>
                            <div class="title">
                                <h5><?php echo e($row->name); ?></h5>
                                <p class="product-code">#<?php echo e($row->options->slug); ?></p>
                                <p class="mobile-date">Date: <?php echo e(date('d/m/Y', strtotime($row->options->add_date_time))); ?> </p>
                                <p class="mobile-time">Time: <?php echo e(strtoupper(date('h:i a', strtotime($row->options->add_date_time)))); ?></p>
                            </div>
                            <div class="date">
                                <p>Date & Time</p>
                                <p><?php echo e(strtoupper(date('d/m/Y h:i a', strtotime($row->options->add_date_time)))); ?></p>
                            </div>
                            <div class="quantity">
                                <div class="product-count" data-avl-qty="<?php echo e($product->remaining_qty); ?>">
                                    <input type="hidden" name="upd_id[]" value="<?php echo e($row->rowId); ?>">
                                    <input type="hidden" name="prod_id[]" value="<?php echo e($row->id); ?>">
                                    <input type="hidden" class="price" value="<?php echo e($row->price); ?>">
                                    <a href="javascript:void(0)" class="qty-minus"><i class="flaticon-minus"></i></a>
                                    <input type="number" value="<?php echo e($row->qty); ?>" class="qty" name="qty[]" readonly>
                                    <a href="javascript:void(0)" class="qty-plus"><i class="flaticon-plus"></i></a>
                                </div>
                            </div>
                            <div class="price">
                                <p>price</p>
                                <p class="qty-price"><?php echo e($row->qty); ?> X $<?php echo e($row->price); ?></p>
                            </div>
                            <div class="remove">
                                <a href="javascript:void(0)" class="reomve-item" data-remvId="<?php echo e($row->rowId); ?>"><i class="flaticon-error"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <div class="ic-contunue-shipping-total">
                    <div class="contunue-shop-update-btn">
                        <a href="<?php echo e(route('shop')); ?>">continue shopping</a>
                        <a href="<?php echo e(route('shopping.cart')); ?>" class="update-btn">update cart</a>
                    </div>
                    <div class="ic-subtotal">
                        <h3 id="subtotal_amount">SUBTOTAl: $<?php echo e(Cart::subtotal()); ?></h3>
                        <p>Discounts will be applied during Check Out</p>
                    </div>
                </div>
            </div>
        </form>
        <div class="ic-continue-checkout-btn">
            <a href="<?php echo e(route('checkout')); ?>" class="ic-btn">continue checkout</a>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="eleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding: 2rem;">
                Do you want to delete this item?
                <input type="hidden" id="del_itme_id">
            </div>
            <div class="modal-footer" style="padding: 0.25rem;">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger delete-btn btn-sm">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            var csrf = "<?php echo e(csrf_token()); ?>";
            var thsRem = '';
            $(document).on("click", ".reomve-item", function(){
                thsRem = $(this);
                var remId = $(this).attr('data-remvId');
                // Confirm box
                $("#del_itme_id").val('');
                $("#deleteModel").modal('show');
                $("#del_itme_id").val(remId);
            });

            $(document).on("click", ".delete-btn", function(){
                var remId = $("#del_itme_id").val();
                $("#loading").show();
                if(remId){
                    $.ajax({
                        type:'post',
                        url: "<?php echo e(route('cart.remove')); ?>",
                        data:{
                            _token:csrf,
                            id:remId,
                        },
                        success:function (data) {
                            $("#loading").hide();
                            $("#subtotal_amount").text('SUBTOTAl: $'+data);
                            thsRem.parent().parent().remove();
                            $('#deleteModel').modal('toggle');

                            toastr.options =
                                {
                                    "closeButton" : true,
                                    "progressBar" : true
                                }
                            toastr.success("Item remove successfully.");
                        }
                    });
                }

            });

            $(document).on("click", ".update-btn", function(e){
                e.preventDefault();
                $("#loading").show();
                var the_form = $(this).closest("form");
                var formdata = the_form.serialize();
                $.ajax({
                    type:'post',
                    url: "<?php echo e(route('cart.update')); ?>",
                    data: formdata,
                    success:function (data) {
                        $("#loading").hide();
                        $('.qty').each(function(i, obj) {
                            var qty = $(this).val();
                            var price = $(this).closest('div').find('.price').val();
                            $(this).parent().parent().parent().find('.qty-price').text(qty +' X $'+ price);
                        });
                        $("#subtotal_amount").text('SUBTOTAl: $'+data);

                        toastr.options =
                            {
                                "closeButton" : true,
                                "progressBar" : true
                            }
                        toastr.success("Cart updated successfully.");
                    }
                });

            });

            $(document).on("click", ".qty-plus", function(e){
                var rem_qty    = $(this).parent().parent().find('.product-count').attr('data-avl-qty');
                var quantity   = $(this).parent().parent().find('.qty').val();
                if(parseInt(quantity) > parseInt(rem_qty)){
                    $(this).parent().parent().find('.qty').val(rem_qty);
                    toastr.options =
                        {
                            "closeButton" : true,
                            "progressBar" : true
                        }
                    toastr.error("Exceed the maximum quota.");
                    return false;
                }

            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/cart.blade.php ENDPATH**/ ?>