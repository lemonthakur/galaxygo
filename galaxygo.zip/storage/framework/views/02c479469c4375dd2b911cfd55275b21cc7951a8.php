<?php
    $sl = 1;
?>
<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
     <td class="text-center"><?php echo e($sl++); ?></td>
    <td>
        <img src="<?php echo e(asset($row->options['player_image'])); ?>" style="width: 50px;height:50px;border-radius:50%;" />
    </td>
    <td>
        Name: <?php echo e(ucwords($row->name)); ?> <br />
        Location: <?php echo e(strtoupper($row->options['location'])); ?> <br/>
        Played On: <?php echo e($row->options['played_on']); ?>

    </td>
    <td>
        Versus: <?php echo e(strtoupper($row->options['versus'])); ?> <br />
        Score: <?php echo e($row->options['score']); ?>

    </td>
    <td class="text-center align-middle">
        <button rowId="<?php echo e($row->rowId); ?>" type="button" class="btn btn-danger btn-xs removeCart">                                                <i class="fas fa-trash"></i>                                                     </button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/contest/player-list.blade.php ENDPATH**/ ?>