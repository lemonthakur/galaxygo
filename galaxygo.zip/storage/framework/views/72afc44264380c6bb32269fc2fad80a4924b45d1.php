<?php if($status == 0): ?>
    <div class="row">
        <div class="col-6">
            <form method="post" action="<?php echo e(route('withdraw.update',$id)); ?>">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="status" value="1">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <button type="submit" class="btn btn-xs btn-success text-white change" title="Approved">
                    <input type="hidden" name="status" value="1">
                    <i class="fas fa-check-circle"></i>
                </button>
            </form>
        </div>
        <div class="col-6 ml-0 pl-0">
            <form method="post" action="<?php echo e(route('withdraw.update',$id)); ?>">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="status" value="2">
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <button type="submit" class="btn btn-xs btn-danger text-white change" title="Canceled">
                    <i class="fas fa-times-circle"></i>
                </button>
            </form>
        </div>
    </div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/withdraw/action.blade.php ENDPATH**/ ?>