<?php if(!empty($aclList[1][3]) || !empty($aclList[1][4])): ?>
    <a class="btn btn-xs btn-primary text-white" href="<?php echo e(route('backend.order.details',$id)); ?>" title="Details" target="_blank">
        <i class="fas fa-eye"></i>
    </a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/orders/action.blade.php ENDPATH**/ ?>