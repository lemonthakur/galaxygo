<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="HTML5,CSS3,SASS,Bootstrap,JavaScript,Jquery">
    <meta name="author" content="ITCLAN BD" />
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($siteSetting->site_title ?? env("APP_NAME")); ?></title>
    <!-- Favicon -->
    <?php if(!empty($siteSetting->icon)): ?>
        <link rel="shortcut icon" type="image/jpg" href="<?php echo e(asset($siteSetting->icon)); ?>"/>
    <?php endif; ?>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/frontend/css/bootstrap.min.css')); ?>">
    <!--Ico Font-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/icofont.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/fonts/flaticon/flaticon.css')); ?>">
    <!--Nice Select-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/nice-select.css')); ?>">
    <!--Owl Carosuel CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
    <!--Animated Css-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.css')); ?>">
    <!--Eazyzoom css--->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/easyzoom.css')); ?>">
    <!--Video js css--->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/video-js.css')); ?>">
    <!--venobox js css--->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/venobox.min.css')); ?>">
    <!-- sweetalert2 css--->
    <link rel="stylesheet" href="<?php echo e(asset("/admin-lte/plugins/toastr/toastr.min.css")); ?>">
    <!--Main CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <!--Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>


    

    <!--Jquery-->
    <script src="<?php echo e(asset('frontend/js/jquery-3.5.1.min.js')); ?>"></script>
    <!--popper Js-->
    <script src="<?php echo e(asset("/admin-lte/plugins/popper/umd/popper.min.js")); ?>"></script>
    <!--Bootstrap Js-->
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <!--sweetalert2 js-->
    <script src="<?php echo e(asset("/admin-lte/plugins/toastr/toastr.min.js")); ?>"></script>
</head>

<body class="ic-body" style="background-image: url('<?php echo e(asset('frontend/images/background-bg.png')); ?>');">

<div id="loading" class="ic-loading">
    <div id="loading-center">
        <div id="loading-center-absolute">
            <div class="object" id="object_one"></div>
            <div class="object" id="object_two"></div>
            <div class="object" id="object_three"></div>
        </div>
    </div>
</div>

<?php echo $__env->make('frontend.include.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Auth::check() && Auth::user()->role_id == 0): ?>
    <?php echo $__env->make('frontend.include.profile-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>;

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--===Scroll Top Area Start===-->
<a href="#" class="ic-scroll-top"><i class="icofont-rounded-up"></i></a>
<!--===Scroll Top Area Start===-->

<!--Owl Carosuel Js-->
<script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
<!--Nice Select js-->
<script src="<?php echo e(asset('frontend/js/jquery.nice-select.js')); ?>"></script>
<!--particles Js-->
<!-- <script src="assets/js/particles.js"></script>
<script src="assets/js/particals-app.js"></script> -->
<!--Eazyzoom js-->
<script src="<?php echo e(asset('frontend/js/easyzoom.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/video.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/js/venobox.min.js')); ?>"></script>
<!--Main Js-->
<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
<!--Custom Js-->
<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
<!--Wow Js-->
<script src="<?php echo e(asset('frontend/js/wow.js')); ?>"></script>
<script>
    new WOW().init();

    $(document).ready(function(){
        $(document).on("click", ".bid-list", function(){
            var id = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-id');
            var csrf = "<?php echo e(csrf_token()); ?>";
            $("#loading").show();

            $.ajax({
                type:'post',
                url: "<?php echo e(route('bid-user.list')); ?>",
                data:{
                    _token:csrf,
                    id:id,
                },
                success:function (data) {
                    $("#list_bidder").empty().html(data.table_data);
                    $("#exampleModalLabel").empty().html(data.model_title);
                    $("#loading").hide();
                }
            });
        });
    });
</script>

<?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/layout/master.blade.php ENDPATH**/ ?>