
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

<section class="ic-product-banner-area">
    <div class="container">
        <div class="ic-product-banner owl-carousel">
            <!--Item 1-->
            <?php if($all_sliders): ?>
                <?php $__currentLoopData = $all_sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item" style="background-image: url('<?php echo e(asset($sv->slider_name)); ?>');">
                        <div class="row">
                            <div class="col-lg-5 col-md-8  offset-lg-6">
                                <div class="content">
                                    <h1><?php echo e($sv->title_black); ?> <span> <?php echo e($sv->title_color); ?></span></h1>
                                    <p><?php echo nl2br($sv->description); ?></p>
                                    <?php if($sv->button_label): ?>
                                        <a href="<?php echo e($sv->link); ?>" class="ic-btn"><?php echo e($sv->button_label); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!--Item End-->
        </div>
    </div>
</section>

<section class="ic-our-product-area">
    <div class="container">
        <div class="ic-our-product-filter">
            <div class="ic-heading">
                <h2>our products</h2>
            </div>
            <div class="ic-filter-btn">
                <a href="javascript:void(0)" class="ic-btn ic-active-link all-pro active">all products</a>
                <a href="javascript:void(0)" class="ic-btn ic-active-link new-pro">new products</a>
                <a href="javascript:void(0)" class="ic-btn ic-active-link fea-pro">feature products</a>
            </div>
        </div>
        <div class="ic-product-warper">
            <div class="row" id="product_list">
                <?php $__empty_1 = true; $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apk => $apv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 ic-col-xs-6">
                        <div class="ic-product-item">
                            <div class="ic-thumbnil">
                                <a href="<?php echo e(route('product-details', $apv->slug)); ?>"><img src="<?php echo e(asset('upload/product-thumbnail-255-200/'.$apv->feature_image)); ?>" class="img-fluid" alt="product"></a>
                                <?php if($apv->remaining_qty<1): ?>
                                    <span class="ic-badge">over</span>
                                <?php endif; ?>
                            </div>
                            <div class="ic-content">
                                <div class="title-price">
                                    <a href="<?php echo e(route('product-details', $apv->slug)); ?>">
                                        <h5><?php echo e($apv->name); ?></h5>
                                        <?php
                                            $price = $apv->price;
                                            if($apv->discount_amount)
                                                $price = $apv->price-$apv->discount_amount;
                                        ?>
                                        <p>$<?php echo e(number_format($price, 2)); ?></p>
                                    </a>
                                </div>
                                <div class="ic-btn-group  custom-add-to-cart-par" data-id="<?php echo e($apv->id); ?>" data-name="<?php echo e($apv->name); ?>" data-price="<?php echo e($price); ?>"
                                     data-discount="<?php echo e($apv->discount_amount); ?>" data-image="<?php echo e($apv->feature_image); ?>"
                                     data-slug="<?php echo e($apv->slug); ?>" data-delivery-charge="<?php echo e($apv->deliver_charge); ?>">
                                        <?php if($apv->remaining_qty>0): ?>
                                            <a href="<?php echo e(route('shopping.cart')); ?>" class="buy-btn custom_add_to_cart">buy now</a>
                                        <?php endif; ?>
                                    <?php if( $apv->auction_end_date.' '.$apv->auction_end_time >= date('Y-m-d H:i:s')): ?>
                                        <a href="<?php echo e(route('product-details', $apv->slug)); ?>" class="bid-btn">bid now</a>
                                        <a href="javascript:void(0);" data-toggle="modal" data-target="#bidModal" class="icon-btn bid-list"><i class="flaticon-time-left"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 text-center"><span class="text-danger">Product not available.</span></div>
                <?php endif; ?>

                <div class="col-md-12">
                    <div class="ic-pagination">
                        <?php echo e($all_products->links('vendor.pagination.frontend')); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            var csrf = "<?php echo e(csrf_token()); ?>";
            var req_type = 'all-pro';
            $(document).on("click", ".all-pro", function(){
                $("#loading").show();
                req_type = 'all-pro';
                ajax_call_for_product('all-pro');
            });

            $(document).on("click", ".new-pro", function(){
                $("#loading").show();
                req_type = 'new-pro';
                ajax_call_for_product('new-pro');
            });

            $(document).on("click", ".fea-pro", function(){
                $("#loading").show();
                req_type = 'fea-pro';
                var ret_val = ajax_call_for_product('fea-pro');
            });

            function ajax_call_for_product(type){
                $.ajax({
                    type:'post',
                    url: "<?php echo e(route('ajax-pro.list')); ?>",
                    data:{
                        _token:csrf,
                        pro_type:type,
                    },
                    success:function (data) {
                        $("#product_list").empty();
                        $("#product_list").html(data);
                        $("#loading").hide();
                    }
                });
            }

            $(document).on("click", ".custom_add_to_cart", function(e){
                e.preventDefault();
                var csrf = "<?php echo e(csrf_token()); ?>";
                $("#loading").show();

                var id         = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-id');
                var name       = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-name');
                var quantity   = 1;
                var price      = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-price');
                var discount   = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-discount');
                var img_name   = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-image');
                var slug       = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-slug');
                var delivery_charge = $(this).parent().parent().find('.custom-add-to-cart-par').attr('data-delivery-charge');

                $.ajax({
                    type:'post',
                    url: "<?php echo e(route('cart.add')); ?>",
                    data:{
                        _token:csrf,
                        id:id,
                        name:name,
                        quantity:quantity,
                        price:price,
                        discount:discount,
                        img_name:img_name,
                        slug:slug,
                        delivery_charge:delivery_charge,
                    },
                    success:function (data) {
                        window.location.href = "<?php echo e(route('shopping.cart')); ?>";
                    }
                });

            });

            $(document).on('click', '.ic-pagination > ul > li > a', function(event){
                event.preventDefault();
                $("#loading").show();
                var page = $(this).attr('href').split('page=')[1];
                fetch_data(page);
            });

            function fetch_data(page)
            {
                $.ajax({
                    url:"<?php echo e(route('ajax-pro.list')); ?>",
                    method:"POST",
                    data:{_token:csrf, page:page, pro_type: req_type},
                    success:function(data)
                    {
                        $("#product_list").empty();
                        $("#product_list").html(data);
                        $("#loading").hide();
                    }
                });
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/shop.blade.php ENDPATH**/ ?>