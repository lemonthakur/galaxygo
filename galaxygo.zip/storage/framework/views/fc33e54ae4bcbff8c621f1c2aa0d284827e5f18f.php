
<!--===Header Area Start===-->

<header>
    <div class="container">
        <div class="ic-header-warper">
            <div class="logo">
                <?php if(!empty($siteSetting->logo)): ?>
                    <a href="<?php echo e(route('home')); ?>" class="large-logo"><img src="<?php echo e(asset($siteSetting->logo)); ?>" class="img-fluid" alt="logo"></a>
                <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>" class="large-logo"><img src="<?php echo e(asset('frontend/images/logo/logo.png')); ?>" class="img-fluid" alt="logo"></a>
                <?php endif; ?>

                <?php if(!empty($siteSetting->icon)): ?>
                    <a href="<?php echo e(route('home')); ?>" class="mobile-logo"><img src="<?php echo e(asset($siteSetting->icon)); ?>" class="img-fluid" alt="logo"></a>
                <?php else: ?>
                    <a href="<?php echo e(route('home')); ?>" class="mobile-logo"><img src="<?php echo e(asset('frontend/images/logo/mobile-logo.png')); ?>" class="img-fluid" alt="logo"></a>
                <?php endif; ?>
            </div>
            <div class="ic-header-right">
                <?php
                    $total_coins = 0.00;
                    if(!\Auth::check()){
                        $mac = strtok(exec('getmac'), ' ');
                        $guestUser = \App\Models\GuestUser::where('mac','=',$mac)->first();
                        if($guestUser)
                            $total_coins = $guestUser->current_coin;
                    }
                ?>
                <a href="<?php echo e(route('login')); ?>" class="ic-btn"><i class="flaticon-login"></i> <span>login</span></a>
                <a href="#" class="ic-btn"><i class="flaticon-coins-1"></i> <span class="lg-coin-bal">Coins Balance: <sapn class="aft-bd-share"><?php echo e($total_coins); ?></sapn></span> <span class="sm-coin-bal aft-bd-share">0.00</span></a>
            </div>
        </div>
    </div>
</header>

<!--===Header Area End===-->
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>