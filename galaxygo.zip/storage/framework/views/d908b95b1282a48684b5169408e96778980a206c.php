<?php $__env->startSection("page-title","Contest-Edit"); ?>
<?php $__env->startSection("main-content"); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Contest</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            
                            
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10 offset-md-1">
                        
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title">Edit Contest</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form method="post" action="<?php echo e(route("contest.update",$contest->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="name">Name<span class="text-danger">*</span></label>
                                                <input readonly type="text"
                                                       class="form-control datepicker <?php echo e($errors->has("name") ? "is-invalid":""); ?>"
                                                       id="name" data-target="#name" data-toggle="datetimepicker"
                                                       name="name" placeholder="Enter User Name"
                                                       value="<?php echo e(old("name",date('d-m-Y',strtotime($contest->name)))); ?>">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("name") ? $errors->first("name") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label for="expaire_time">Count Down Timer<span
                                                        class="text-danger">*</span></label>
                                                <input readonly type="text"
                                                       class="form-control timepicker <?php echo e($errors->has("expaire_time") ? "is-invalid":""); ?>"
                                                       id="expaire_time" data-target="#expaire_time"
                                                       data-toggle="datetimepicker" name="expaire_time"
                                                       placeholder="Enter Count Down Time"
                                                       value="<?php echo e(old("expaire_time",$contest->expaire_time)); ?>">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("expaire_time") ? $errors->first("expaire_time") : ""); ?> </span>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <button style="margin-top: 25%;" type="submit" class="btn btn-dark">Update
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </form>
                        </div>

                        
                        <div class="card card-dark mt-3">
                            <div class="card-header">
                                <h3 class="card-title">Edit Players</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->

                            <div class="card-body">
                                <form method="post" action="<?php echo e(route("contest-player.store")); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="contest_id" value="<?php echo e($contest->id); ?>">
                                    <div class="row">

                                        <div class="col-md-12 text-center">
                                            <h4 class="text-center">Player Add</h4>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="player_name">Player Name<span
                                                        class="text-red">*</span></label>
                                                <input type="text"
                                                       class="form-control <?php echo e($errors->has("player_name") ? "is-invalid":""); ?>"
                                                       name="player_name" id="player_name" placeholder="Player Name"
                                                       value="<?php echo e(old('player_name')); ?>">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("player_name") ? $errors->first("player_name") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="location">Location<span class="text-red">*</span></label>
                                                <input type="text"
                                                       class="form-control <?php echo e($errors->has("location") ? "is-invalid":""); ?>"
                                                       id="location" placeholder="Location"
                                                name="location" value="<?php echo e(old('location')); ?>">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("location") ? $errors->first("location") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="played_on">Played On<span class="text-red">*</span></label>
                                                <input type="text" readonly
                                                       class="form-control datetimepicker <?php echo e($errors->has("played_on") ? "is-invalid":""); ?>"
                                                       id="played_on" data-target="#played_on"
                                                       data-toggle="datetimepicker" placeholder="play time"
                                                       name="played_on" value="<?php echo e(old('played_on')); ?>">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("location") ? $errors->first("location") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="versus">Versus<span class="text-red">*</span></label>
                                                <input type="text"
                                                       class="form-control <?php echo e($errors->has("versus") ? "is-invalid":""); ?>"
                                                       id="versus" placeholder="Versus"
                                                name="versus" value="<?php echo e(old('versus')); ?>">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("versus") ? $errors->first("versus") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="score">Score<span class="text-red">*</span></label>
                                                <input type="number" step="any"
                                                       class="form-control <?php echo e($errors->has("score") ? "is-invalid":""); ?>"
                                                       id="score" placeholder="Score"
                                                name="score" value="<?php echo e(old('score')); ?>">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("score") ? $errors->first("score") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="player_image">Player Image<span
                                                        class="text-red">*</span></label>
                                                <input type="file"
                                                       class="form-control <?php echo e($errors->has("player_image") ? "is-invalid":""); ?>"
                                                       accept="image/png, image/gif, image/jpeg" id="player_image"
                                                       placeholder="Player Image" name="player_image">
                                                <span
                                                    class="text-danger"><?php echo e($errors->has("player_image") ? $errors->first("player_image") : ""); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-2 text-right">
                                            <button type="submit" style="margin-top: 24%;"
                                                    class="btn btn-info">Add Player
                                            </button>
                                        </div>

                                    </div>
                                </form>

                                <table id="player-table" class="table table-bordered table-striped mt-3">
                                    <thead>
                                    <tr>
                                        <th colspan="4" class="text-center">Added Player</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $sl = 1;
                                    ?>
                                    <?php $__currentLoopData = $contest->contestPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($sl++); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($player->player_image)); ?>"
                                                     style="width: 50px;height:50px;border-radius:50%;"/>
                                            </td>
                                            <td>
                                                Name: <?php echo e(ucwords($player->player_name)); ?> <br/>
                                                Location: <?php echo e(strtoupper($player->location)); ?> <br/>
                                                Played On: <?php echo e(date('d-m-Y H:i a',strtotime($player->played_on))); ?>

                                            </td>
                                            <td>
                                                Versus: <?php echo e(strtoupper($player->versus)); ?> <br/>
                                                Score: <?php echo e($player->score); ?>

                                            </td>
                                            <td class="text-center align-middle">
                                                <form method="post"
                                                      action="<?php echo e(route('contest-player.destroy',$player->id)); ?>">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit"
                                                            class="btn btn-xs btn-danger text-white delete"
                                                            title="Delete">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.master.main-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/contest/edit.blade.php ENDPATH**/ ?>