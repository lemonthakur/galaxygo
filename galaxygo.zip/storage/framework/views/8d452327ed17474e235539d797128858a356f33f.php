<ul>
    <?php if(!$paginator->onFirstPage()): ?>
        <li><a class="previous" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">Previous</a></li>
    <?php endif; ?>


<?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if(is_string($element)): ?>
        <li class="disabled"><span><?php echo e($element); ?></span></li>
    <?php endif; ?>



    <?php if(is_array($element)): ?>
        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $paginator->currentPage()): ?>
                    <li><a href="#" class="active"><?php echo e($page); ?></a></li>
            <?php else: ?>
                <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($paginator->hasMorePages()): ?>
            <li><a class="next" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next</a></li>
        <?php endif; ?>
</ul>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/vendor/pagination/frontend.blade.php ENDPATH**/ ?>