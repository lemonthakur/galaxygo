<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
        <?php if(!$siteSetting->logo): ?>
            <img src="<?php echo e(asset("/public/admin-lte/dist/img/AdminLTELogo.png")); ?>" alt="Company Logo"
                 class="brand-image img-circle elevation-3"
                 style="opacity: .8">
            <span class="brand-text font-weight-light"><?php echo e(ucwords($siteSetting->site_title ?? '')); ?></span>
        <?php else: ?>
            <img src="<?php echo e(asset($siteSetting->logo)); ?>" alt="Company Logo"
                 class="brand-image">
        <?php endif; ?>
        <span class="brand-text font-weight-light d-inline-block"></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->photo): ?>
                        <img src="<?php echo e(asset(auth()->user()->photo)); ?>" class="img-circle elevation-2" alt="User Image">
                    <?php else: ?>
                        <img src="<?php echo e(asset("/public/demo-pic/profile.png")); ?>" class="img-circle elevation-2"
                             alt="User Image">
                    <?php endif; ?>
                <?php elseif(auth()->guard()->check()): ?>
                    <img src="<?php echo e(asset("/public/demo-pic/profile.png")); ?>" class="img-circle elevation-2"
                         alt="User Image">
                <?php endif; ?>
            </div>
            <div class="info">
                <?php if(auth()->guard()->check()): ?>
                    <a href="#" class="d-block"><?php echo e(auth()->user()->name); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <?php if(!empty($aclList[6][1])): ?>
                    <li class="nav-item has-treeview <?php echo e(($routeName == 'user.index' || $routeName == 'user.create' || $routeName == 'user.edit') ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>
                                User Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!empty($aclList[6][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("user.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'user.index' || $routeName == 'user.create'|| $routeName == 'user.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Admin Panel User</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                 <?php if(!empty($aclList[1][1]) || !empty($aclList[2][1]) || !empty($aclList[3][1])): ?>
                    <li class="nav-item has-treeview <?php echo e(($routeName == 'role.index' || $routeName == 'role.create' || $routeName == 'role.edit' || $routeName == 'role.access' || $routeName == 'user.access') ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>
                                Access Control
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!empty($aclList[1][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("role.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'role.index' || $routeName == 'role.create'|| $routeName == 'role.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Role Management</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[2][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("role.access")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'role.access') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Role Access Control</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[3][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("user.access")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'user.access') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>User Access Control</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                <?php endif; ?>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'contest.index' || $routeName == 'contest.create' || $routeName == 'contest.edit') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-play-circle"></i>
                        <p>
                            Contest Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("contest.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'contest.index' || $routeName == 'contest.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Contest List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("contest.create")); ?>"
                               class="nav-link <?php echo e(($routeName == 'contest.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Contest Create</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'win-coin.index' || $routeName == 'win-coin.create' || $routeName == 'win-coin.edit') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-coins"></i>
                        <p>
                            Contest Win Coin
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("win-coin.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'win-coin.index' || $routeName == 'win-coin.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Contest Win Coin List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("win-coin.create")); ?>"
                               class="nav-link <?php echo e(($routeName == 'win-coin.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Contest Win Coin Create</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'category.index' || $routeName == 'category.create' || $routeName == 'category.edit'
                 || $routeName == 'brand.index' || $routeName == 'brand.create' || $routeName == 'brand.edit'
                 || $routeName == 'product.index' || $routeName == 'product.create' || $routeName == 'product.edit' || $routeName == 'auction-product.list') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            Product Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("category.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'category.index' || $routeName == 'category.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Category List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("category.create")); ?>"
                               class="nav-link <?php echo e(($routeName == 'category.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Category Create</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route("brand.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'brand.index' || $routeName == 'brand.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Brand List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("brand.create")); ?>"
                               class="nav-link <?php echo e(($routeName == 'brand.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Brand Create</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route("product.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'product.index' || $routeName == 'product.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Product List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("product.create")); ?>"
                               class="nav-link <?php echo e(($routeName == 'product.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Product Create</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("auction-product.list")); ?>"
                               class="nav-link <?php echo e(($routeName == 'auction-product.list') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Auction Product List</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'backend.order.view' || $routeName == 'backend.order.details'
                || $routeName == 'backend.auction.order.view') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            Order Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("backend.order.view")); ?>"
                               class="nav-link <?php echo e(($routeName == 'backend.order.view' || $routeName == 'backend.order.details'|| $routeName == 'backend.order.print') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Orders</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route("backend.auction.order.view")); ?>"
                               class="nav-link <?php echo e(($routeName == 'backend.auction.order.view') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Auction Orders</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'withdraw.index' ) ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            Withdraw
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("withdraw.index")); ?>"
                               class="nav-link <?php echo e(($routeName == 'withdraw.index') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>WIthdraw Request List</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'product.stock.report' ) ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            Report
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("product.stock.report")); ?>"
                               class="nav-link <?php echo e(($routeName == 'product.stock.report') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Stock Report</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview <?php echo e(($routeName == 'about-us.edit' || $routeName == 'other-page.edit') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-coins"></i>
                        <p>
                            Pages
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route("about-us.edit")); ?>"
                               class="nav-link <?php echo e(($routeName == 'about-us.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>About Us</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route("other-page.edit")); ?>"
                               class="nav-link <?php echo e(($routeName == 'other-page.edit') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Other Pages</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <?php if(!empty($aclList[4][1]) || !empty($aclList[5][1]) || !empty($aclList[10][3])
                 || !empty($aclList[10][3]) ): ?>
                    <li class="nav-item has-treeview <?php echo e(($routeName == 'activity.index' || $routeName == 'activity.create'
                    || $routeName == 'activity.edit' || $routeName == 'module.index' || $routeName == 'module.create'
                    || $routeName == 'module.edit' || $routeName == 'site.setting.edit' || $routeName == 'slider.create'
                    || $routeName == 'slider.edit' || $routeName == 'slider.index' || $routeName == 'footer-circle-image.index'
                    || $routeName == 'footer-circle-image.create' || $routeName == 'footer-circle-image.edit') ? 'menu-open' : ''); ?>">
                        <a href="#"
                           class="nav-link">
                            <i class="nav-icon fas fa-cog"></i>
                            <p>
                                Setting
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!empty($aclList[4][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("module.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'module.index' || $routeName == 'module.create'|| $routeName == 'module.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Module Management</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[5][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("activity.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'activity.index' || $routeName == 'activity.create'|| $routeName == 'activity.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Activity Management</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[10][3])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("site.setting.edit")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'site.setting.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Site Setting</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[5][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("slider.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'slider.index' || $routeName == 'slider.create'|| $routeName == 'slider.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Slider</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!empty($aclList[5][1])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("footer-circle-image.index")); ?>"
                                       class="nav-link <?php echo e(($routeName == 'footer-circle-image.index' || $routeName == 'footer-circle-image.create'|| $routeName == 'footer-circle-image.edit') ? 'active' : ''); ?>">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>Footer circle image</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>
                            Logout
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/include/left-side-navbar.blade.php ENDPATH**/ ?>