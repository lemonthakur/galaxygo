<?php if(!empty($aclList[1][3]) || !empty($aclList[1][4])): ?>
    <form method="post" action="<?php echo e(route('product.destroy',$id)); ?>">
        <?php if(!empty($aclList[1][3])): ?>
            <a class="btn btn-xs btn-warning text-white" href="<?php echo e(route('bid.users.list', $id)); ?>" title="User List">
                <i class="fas fa-list"></i>
            </a>
        <?php endif; ?>
        
    </form>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/product/auction_action.blade.php ENDPATH**/ ?>