<?php $__env->startSection('title','Privacy Policy'); ?>

<?php $__env->startSection('content'); ?>
    <section class="ic-privacy-policy-area">
        <div class="container">
            <div class="ic-privacy-policy-tab">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#privacyPolicy" role="tab">privacy policy</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#termsCondition" role="tab">terms & conditions</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#rules" role="tab">Rules</a>
                    </li>

                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="privacyPolicy">
                        <div class="ic-privacy-policy-tab-content">
                            <h2>Privacy Policy</h2>
                            <div>
                                <?php echo $otherPage->privacy_policy; ?>

                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="termsCondition">
                        <div class="ic-privacy-policy-tab-content">
                            <h2>terms & conditions</h2>
                            <?php echo $otherPage->terms_condition; ?>

                        </div>
                    </div>

                    <div class="tab-pane fade" id="rules">
                        <div class="ic-privacy-policy-tab-content">
                            <h2>Rules</h2>
                            <?php echo $otherPage->rules; ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/frontend/pages.blade.php ENDPATH**/ ?>