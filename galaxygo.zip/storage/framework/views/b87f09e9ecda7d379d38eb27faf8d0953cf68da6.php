<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        <a href="https://itclanbd.com" target="_blank">Design and Develop by ITclan BD</a>
    </div>
    <!-- Default to the left -->
<!--<strong>Copyright &copy; 2020-<?php echo e(date('Y')); ?> <?php echo e(ucwords($siteSetting->site_title ?? '')); ?> .</strong> All rights reserved.-->
    <strong>Copyright ©️ 2021 <?php echo e(ucwords($siteSetting->site_title ?? '')); ?>. All rights reserved.</strong>
</footer>
<?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/include/footer.blade.php ENDPATH**/ ?>