<?php $__env->startSection("page-title","About Us"); ?>
<?php $__env->startSection("main-content"); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">About Us</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            
                            
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title">Edit About Us</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form method="post" action="<?php echo e(route("about-us.update")); ?>" id="slider_form"
                                  enctype="multipart/form-data">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>

                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title">Title<span class="text-red">*</span></label>
                                                <input type="text"
                                                       class="form-control <?php echo e($errors->has("title") ? "is-invalid":""); ?>"
                                                       id="title" name="title" placeholder="Enter page title"
                                                       value="<?php echo e(old("title",$aboutUs->title)); ?>"
                                                       required maxlength="50">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("title") ? $errors->first("title") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="button_text">Button Text<span
                                                        class="text-red">*</span></label>
                                                <input type="text"
                                                       class="form-control <?php echo e($errors->has("button_text") ? "is-invalid":""); ?>"
                                                       id="button_text" name="button_text"
                                                       placeholder="Enter button text"
                                                       value="<?php echo e(old("button_text",$aboutUs->button_text)); ?>"
                                                       required maxlength="30">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("button_text") ? $errors->first("button_text") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="button_url">Button Url<span
                                                        class="text-red">*</span></label>
                                                <input type="url"
                                                       class="form-control <?php echo e($errors->has("button_url") ? "is-invalid":""); ?>"
                                                       id="button_url" name="button_url" placeholder="Enter button url"
                                                       value="<?php echo e(old("button_url",$aboutUs->button_url)); ?>"
                                                       required maxlength="255">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("button_url") ? $errors->first("button_url") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="video_url">Video Url</label>
                                                <input type="url"
                                                       class="form-control <?php echo e($errors->has("video_url") ? "is-invalid":""); ?>"
                                                       id="video_url" name="video_url" placeholder="Enter video url"
                                                       value="<?php echo e(old("video_url",$aboutUs->video_url)); ?>"
                                                       required maxlength="255">
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("video_url") ? $errors->first("video_url") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description">Description</label>
                                                <textarea
                                                    class="txt-editor form-control <?php echo e($errors->has("description") ? "is-invalid":""); ?>"
                                                    id="description" name="description"
                                                    placeholder="Enter page description"><?php echo e(old("description",$aboutUs->description)); ?></textarea>
                                                <span
                                                    class="text-danger"> <?php echo e($errors->has("description") ? $errors->first("description") : ""); ?> </span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <label>
                                                
                                                Upload Image
                                            </label>
                                            <p><input type="file" accept="image/*" name="image" class="logo" id="logo"
                                                      style="display: none;"></p>
                                            <p><label for="logo" style="cursor: pointer;">
                                                    <?php if(!$aboutUs->image): ?>
                                                        <img id="outputLogo"
                                                             src="<?php echo e(asset('/demo-pic/upload-image.jpg')); ?>"
                                                             width="180"/>
                                                    <?php else: ?>
                                                        <img id="outputLogo" src="<?php echo e(asset($aboutUs->image)); ?>"
                                                             width="180"/>
                                                    <?php endif; ?>
                                                </label></p>
                                            <span
                                                class="text-danger"> <?php echo e($errors->has("logo") ? $errors->first("logo") : ""); ?> </span>
                                        </div>

                                        <div class="col-md-6">
                                            <label>
                                                
                                                Upload video banner
                                            </label>
                                            <p><input type="file" accept="image/*" name="video_banner" class="image"
                                                      id="image" style="display: none;"></p>
                                            <p><label for="image" style="cursor: pointer;">
                                                    <?php if(!$aboutUs->video_banner): ?>
                                                        <img id="output" src="<?php echo e(asset('/demo-pic/upload-image.jpg')); ?>"
                                                             width="180"/>
                                                    <?php else: ?>
                                                        <img id="output" src="<?php echo e(asset($aboutUs->video_banner)); ?>"
                                                             width="180"/>
                                                    <?php endif; ?>
                                                </label></p>
                                            <span
                                                class="text-danger"> <?php echo e($errors->has("video_banner") ? $errors->first("video_banner") : ""); ?> </span>
                                        </div>

                                    </div>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-dark">Update</button>
                                    <!-- <button type="button" class="btn btn-default cancel">Cancel</button> -->
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            tinymceInitial();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.master.main-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l\galaxygo\resources\views/backend/about-us/edit.blade.php ENDPATH**/ ?>